import React from 'react';
import { Link } from 'react-router-dom';
// Import Bootstrap CSS for layout and styling
import 'bootstrap/dist/css/bootstrap.min.css';
// Custom CSS files for additional styling
import './css/indexA.css';
import './css/indexB.css';
// Image imports for use in the component
import tvStationImage from './images/PUiYqFSTKeUmdKAe6mcWm8.jpg'; // TV Station image
import gamingPcImage from './images/How_to_build_gaming_PC.png'; // Gaming PC image
import poolTableImage from './images/7-smart-ways-to-fit-a-pool-table-into-your-home-693657.webp'; // Pool table image
import csunGameLogo from './images/csungame.png'; // CSUN Games Room logo

function Home() {
  return (
    <div className="background">
      {/* Navigation bar with links to other pages */}
      <nav className="navbar navbar-expand-lg navbar-custom navbar-dark sticky-top shadow-lg">
        <div className="container-fluid">
          {/* Link component for SPA navigation, acts as logo and home button */}
          <Link className="navbar-brand mx-5" to="/"><b>CSUN GAMES ROOM</b></Link>
          {/* Toggle button for small screens */}
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          {/* Collapsible part of the navigation bar */}
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item mx-3">
                <Link className="nav-link active" to="/">Home</Link>
              </li>
              <li className="nav-item mx-3">
                <Link className="nav-link" to="/about">About</Link>
              </li>
              <li className="nav-item mx-3">
                <Link className="nav-link" to="/contact">Contact Us</Link>
              </li>
              <li className="nav-item">
                {/* Logo image on the navbar */}
                <img src={csunGameLogo} alt="CSUN Games Room Logo" className="navbar-image mr-5"/>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      
      {/* Section with a welcome message */}
      <div className='separate'> {/* Changed from 'separate' */}
        <section > {/* Removed 'hidden' */}
          <h1>WELCOME TO THE CSUN GAMES ROOM!</h1>
        </section>
      </div>
        
      {/* Section with links to game room features */}
      <section> {/* Removed 'hidden' */}
        <h1>Queue Up To Start!</h1>
        <div className="row">
          <div className="col-md-4">
            {/* TV Stations section with link */}
            <div className="text-center mb-3">
              <img src={tvStationImage} alt="TV Stations" className="img-fluid rounded medium-image"/>
            </div>
            <div className="text-center">
              <Link to="/consoles" className="btn grn-btn rounded-pill shadow">TV STATIONS!</Link>
            </div>
          </div>
          
          <div className="col-md-4">
            {/* Computers section with link */}
            <div className="text-center mb-3">
              <img src={gamingPcImage} alt="Gaming PC" className="img-fluid rounded medium-image"/>
            </div>
            <div className="text-center">
              <Link to="/computers" className="btn grn-btn rounded-pill shadow">COMPUTERS!</Link>
            </div>
          </div>
          
          <div className="col-md-4">
            {/* Pool table section with link */}
            <div className="text-center mb-3">
              <img src={poolTableImage} alt="Pool Table" className="img-fluid rounded medium-image"/>
            </div>
            <div className="text-center">
              <Link to="/poolTables" className="btn grn-btn rounded-pill shadow">POOL!</Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;
