import React from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'; // Ensure Bootstrap is included in your project
import './css/dashboardStyle.css'; // Main dashboard CSS
import './css/newS.css'; // Additional styling CSS
import csunGameLogo from './images/csungame.png'; // Logo image

function OurStory() {
  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-custom navbar-dark sticky-top shadow-lg">
        <div className="container-fluid">
          <Link className="navbar-brand mx-5" to="/"><b>CSUN GAMES ROOM</b></Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item mx-3">
                <Link className="nav-link active" to="/">Home</Link>
              </li>
              <li className="nav-item mx-3">
                <Link className="nav-link" to="/about">About</Link>
              </li>
              <li className="nav-item mx-3">
                <Link className="nav-link" to="/contact">Contact Us</Link>
              </li>
            </ul>
            <img src={csunGameLogo} alt="CSUN Games Room Logo" className="navbar-image mr-5"/>
          </div>
        </div>
      </nav>

      <div className="container mt-5">
        <div className="pgtitle">
          <h1>Our Story</h1>
        </div>
        <div className="about">
          <h2>By CSUN students for CSUN students</h2>
          <p>
            Our journey began with a frustrating experience – co-founder Ken Simon's overcrowded trip to the USU. It was then that the spark ignited, the realization that there had to be a better way. Inspired by this inconvenience, Ken envisioned an appointment system for the USU, one that would streamline access and ease the burden of overcrowding. Drawing from his own experiences and insights gained while working for CSUN, co-founder Jordan contributed invaluable perspectives, potentially transforming this vision into reality.
          </p>
          <p>
            With the collaborative efforts of co-founders Rita and Mikey, our team is committed to ensuring that every student maximizes the potential of the USU games room. Together, we strive to create a solution that not only addresses the challenges we face as CSUN students but also enhances our campus experience. Let's make accessing the USU a seamless and enjoyable experience for all!
          </p>
        </div>
      </div>
    </>
  );
}

export default OurStory;
