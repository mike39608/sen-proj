import React, { useEffect, useState } from 'react';
import Axios from 'axios';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'; // Bootstrap for styling
import './css/dashboardStyle.css'; // Custom CSS for the dashboard
import csunGameLogo from './images/csungame.png'; // CSUN Games Room logo
import poolTableImage from './images/1047118.png'; // Pool table image
import gamingPcImage from './images/—Pngtree—desktop computer icon in line_5045604.png'; // Computer icon image
import tvStationImage from './images/24-tv_101173.png'; // TV station image

function formatDate(dateString) {
  const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
  return new Date(dateString).toLocaleDateString(undefined, options);
}

function Dashboard() {
  const [machines, setMachines] = useState([]);

  useEffect(() => {
    const fetchMachines = async () => {
      try {
        const response = await Axios.get('http://localhost:5000/machines');
        const sortedMachines = response.data.Machines.sort((a, b) => {
          return a.Name.localeCompare(b.Name);
        });
        setMachines(sortedMachines);
      } catch (error) {
        console.error("Failed to fetch machines:", error);
      }
    };

    fetchMachines();
  }, []);

  return (
    <div className="container-fluid">
      <nav className="navbar navbar-expand-lg navbar-custom navbar-dark sticky-top shadow-lg">
        <div className="container-fluid">
          <Link className="navbar-brand mx-5" to="/"><b>CSUN GAMES ROOM</b></Link>
          <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item mx-3">
                <Link className="nav-link active" to="/">Home</Link>
              </li>
              <li className="nav-item mx-3">
                <Link className="nav-link" to="/about">About</Link>
              </li>
              <li className="nav-item mx-3">
                <Link className="nav-link" to="/contact">Contact Us</Link>
              </li>
              <img src={csunGameLogo} alt="CSUN Games Room Logo" className="navbar-image mr-5"/>
            </ul>
          </div>
        </div>
      </nav>

      <div className="row">
        <div className="side-bar shadow-sm col-lg-3">
          <div className="container grid">
            <div className="card my-5">
              <Link to="/poolTables">
                <h5>Pool Tables</h5>
                <img src={poolTableImage} alt="Pool Tables" className="img-fluid"/>
              </Link>
            </div>
            <div className="card my-5">
              <Link to="/computers">
                <h5>Computers</h5>
                <img src={gamingPcImage} alt="Computers" className="img-fluid"/>
              </Link>
            </div>
            <div className="card my-5">
              <Link to="/consoles">
                <h5>TV Stations</h5>
                <img src={tvStationImage} alt="TV Stations" className="img-fluid"/>
              </Link>
            </div>
          </div>
        </div>

        <main className="dashboard col-lg-9">
          <div className="mt-5">
            <h1 className="med-text d-flex justify-content-center"><b>Computers!</b></h1>
            <br />
          </div>
          <div className="row">
            {machines.map((machine) => (
              <div className="col-md-6" key={machine.Uuid}>
                <div className="card mb-3">
                  <h5 className="card-header">{machine.Name}</h5>
                  <div className="card-body">
                    <ul className="list-group list-group-flush" style={{ listStyleType: 'none' }}>
                      <li>State: {machine.State}</li>
                      <li>Last Update: {formatDate(machine.LastUpdate)}</li>
                      <li>Last State Update: {formatDate(machine.LastStateUpdate)}</li>
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}

export default Dashboard;
