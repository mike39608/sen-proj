import React, { useEffect, useState } from 'react';
import Axios from 'axios';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './css/dashboardStyle.css';
import csunGameLogo from './images/csungame.png';
import poolTableImage from './images/1047118.png';
import gamingPcImage from './images/—Pngtree—desktop computer icon in line_5045604.png';
import tvStationImage from './images/24-tv_101173.png';

function Dashboard() {
  // State variables for storing devices data, loading status, and error messages
  const [machineData, setMachineData] = useState({ Devices: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // useEffect to fetch data from the server when the component mounts
  useEffect(() => {
    async function fetchData() {
      try {
        // Request data from the backend API
        const response = await Axios.get('http://localhost:5000/consoles');
        console.log("API Data:", response.data);
        // Set the fetched data to state
        setMachineData(response.data);
      } catch (error) {
        // Handle any errors during fetching
        console.error("Fetching devices failed", error);
        setError(error);
      } finally {
        // Disable loading indicator regardless of request outcome
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  // Conditional rendering based on the loading state
  if (loading) return <p>Loading...</p>;
  // Conditional rendering based on the presence of an error
  if (error) return <p>Error loading data: {error.message}</p>;

  return (
    <div className="App">
      {/* Navigation bar with links to different pages */}
      <nav className="navbar navbar-expand-lg navbar-custom navbar-dark sticky-top shadow-lg">
        <div className="container-fluid">
          <Link className="navbar-brand mx-5" to="/"><b>CSUN GAMES ROOM</b></Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item mx-3">
                <Link className="nav-link active" to="/">Home</Link>
              </li>
              <li className="nav-item mx-3">
                <Link className="nav-link" to="/about">About</Link>
              </li>
              <li className="nav-item mx-3">
                <Link className="nav-link" to="/contact">Contact Us</Link>
              </li>
            </ul>
            <img src={csunGameLogo} alt="CSUN Games Room Logo" className="navbar-image mr-5"/>
          </div>
        </div>
      </nav>

      {/* Sidebar for different game room options */}
      <div className="side-bar shadow-sm col-lg-3">
        <div className="container grid">
          <div className="card my-5">
            <Link to="/poolTables">
              <h5>Pool Tables</h5>
              <img src={poolTableImage} alt="Pool Tables" className="img-fluid"/>
            </Link>
          </div>
          <div className="card my-5">
            <Link to="/computers">
              <h5>Computers</h5>
              <img src={gamingPcImage} alt="Computers" className="img-fluid"/>
            </Link>
          </div>
          <div className="card my-5">
            <Link to="/consoles">
              <h5>TV Stations</h5>
              <img src={tvStationImage} alt="TV Stations" className="img-fluid"/>
            </Link>
          </div>
        </div>
      </div>

      {/* Main content area for displaying pool tables with dynamic titles */}
      <main className="dashboard col-lg-9">
        <div className="mt-5">
          <h1 className="med-text d-flex justify-content-center"><b>Pool Tables:</b></h1>
          <br />
        </div>
        <div className="row">
          {machineData.Devices.filter(device => device.Type === "Other").map((device, index) => (
            <div className="col-md-6" key={device.Uuid}>
              <div className="card mb-3">
                <h5 className="card-header">{`Pool Table ${index + 1}`}</h5>
                <div className="card-body">
                  <ul className="list-group list-group-flush" style={{ listStyleType: 'none' }}>
                    <li>User: {device.Name}</li>
                    <li>Type: {device.Type}</li>
                    <li>Uuid: {device.Uuid}</li>
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="container-fluid mt-4">
          <div className="row justify-content-center" id="resource-list"></div>
        </div>
      </main>
    </div>
  );
}

export default Dashboard;
